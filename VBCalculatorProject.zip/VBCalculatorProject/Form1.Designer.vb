﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Number0 = New System.Windows.Forms.Button()
        Me.Point = New System.Windows.Forms.Button()
        Me.Equal = New System.Windows.Forms.Button()
        Me.Addition = New System.Windows.Forms.Button()
        Me.Number3 = New System.Windows.Forms.Button()
        Me.Number2 = New System.Windows.Forms.Button()
        Me.Number1 = New System.Windows.Forms.Button()
        Me.Subtraction = New System.Windows.Forms.Button()
        Me.Number6 = New System.Windows.Forms.Button()
        Me.Number5 = New System.Windows.Forms.Button()
        Me.Number4 = New System.Windows.Forms.Button()
        Me.Multiplication = New System.Windows.Forms.Button()
        Me.Number9 = New System.Windows.Forms.Button()
        Me.Number8 = New System.Windows.Forms.Button()
        Me.Number7 = New System.Windows.Forms.Button()
        Me.Division = New System.Windows.Forms.Button()
        Me.cancel1 = New System.Windows.Forms.Button()
        Me.Erasebutton = New System.Windows.Forms.Button()
        Me.Label = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Number0
        '
        Me.Number0.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Number0.Font = New System.Drawing.Font("Microsoft YaHei", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Number0.Location = New System.Drawing.Point(9, 371)
        Me.Number0.Name = "Number0"
        Me.Number0.Size = New System.Drawing.Size(86, 67)
        Me.Number0.TabIndex = 1
        Me.Number0.Text = "0"
        Me.Number0.UseVisualStyleBackColor = False
        '
        'Point
        '
        Me.Point.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Point.Font = New System.Drawing.Font("Microsoft YaHei", 20.0!, System.Drawing.FontStyle.Bold)
        Me.Point.Location = New System.Drawing.Point(95, 371)
        Me.Point.Name = "Point"
        Me.Point.Size = New System.Drawing.Size(86, 67)
        Me.Point.TabIndex = 2
        Me.Point.Text = "."
        Me.Point.UseVisualStyleBackColor = False
        '
        'Equal
        '
        Me.Equal.BackColor = System.Drawing.Color.Orange
        Me.Equal.Font = New System.Drawing.Font("Microsoft YaHei", 20.0!, System.Drawing.FontStyle.Bold)
        Me.Equal.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Equal.Location = New System.Drawing.Point(267, 371)
        Me.Equal.Name = "Equal"
        Me.Equal.Size = New System.Drawing.Size(173, 67)
        Me.Equal.TabIndex = 3
        Me.Equal.Text = "="
        Me.Equal.UseVisualStyleBackColor = False
        '
        'Addition
        '
        Me.Addition.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Addition.Font = New System.Drawing.Font("Microsoft YaHei", 20.0!, System.Drawing.FontStyle.Bold)
        Me.Addition.Location = New System.Drawing.Point(267, 297)
        Me.Addition.Name = "Addition"
        Me.Addition.Size = New System.Drawing.Size(86, 68)
        Me.Addition.TabIndex = 7
        Me.Addition.Text = "+"
        Me.Addition.UseVisualStyleBackColor = False
        '
        'Number3
        '
        Me.Number3.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Number3.Font = New System.Drawing.Font("Microsoft YaHei", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Number3.Location = New System.Drawing.Point(181, 297)
        Me.Number3.Name = "Number3"
        Me.Number3.Size = New System.Drawing.Size(86, 68)
        Me.Number3.TabIndex = 6
        Me.Number3.Text = "3"
        Me.Number3.UseVisualStyleBackColor = False
        '
        'Number2
        '
        Me.Number2.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Number2.Font = New System.Drawing.Font("Microsoft YaHei", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Number2.Location = New System.Drawing.Point(95, 297)
        Me.Number2.Name = "Number2"
        Me.Number2.Size = New System.Drawing.Size(86, 68)
        Me.Number2.TabIndex = 5
        Me.Number2.Text = "2"
        Me.Number2.UseVisualStyleBackColor = False
        '
        'Number1
        '
        Me.Number1.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Number1.Font = New System.Drawing.Font("Microsoft YaHei", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Number1.Location = New System.Drawing.Point(9, 297)
        Me.Number1.Name = "Number1"
        Me.Number1.Size = New System.Drawing.Size(86, 68)
        Me.Number1.TabIndex = 4
        Me.Number1.Text = "1"
        Me.Number1.UseVisualStyleBackColor = False
        '
        'Subtraction
        '
        Me.Subtraction.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Subtraction.Font = New System.Drawing.Font("Microsoft YaHei", 25.0!, System.Drawing.FontStyle.Bold)
        Me.Subtraction.Location = New System.Drawing.Point(267, 223)
        Me.Subtraction.Name = "Subtraction"
        Me.Subtraction.Size = New System.Drawing.Size(86, 68)
        Me.Subtraction.TabIndex = 11
        Me.Subtraction.Text = "-"
        Me.Subtraction.UseVisualStyleBackColor = False
        '
        'Number6
        '
        Me.Number6.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Number6.Font = New System.Drawing.Font("Microsoft YaHei", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Number6.Location = New System.Drawing.Point(181, 223)
        Me.Number6.Name = "Number6"
        Me.Number6.Size = New System.Drawing.Size(86, 68)
        Me.Number6.TabIndex = 10
        Me.Number6.Text = "6"
        Me.Number6.UseVisualStyleBackColor = False
        '
        'Number5
        '
        Me.Number5.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Number5.Font = New System.Drawing.Font("Microsoft YaHei", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Number5.Location = New System.Drawing.Point(95, 223)
        Me.Number5.Name = "Number5"
        Me.Number5.Size = New System.Drawing.Size(86, 68)
        Me.Number5.TabIndex = 9
        Me.Number5.Text = "5"
        Me.Number5.UseVisualStyleBackColor = False
        '
        'Number4
        '
        Me.Number4.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Number4.Font = New System.Drawing.Font("Microsoft YaHei", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Number4.Location = New System.Drawing.Point(9, 223)
        Me.Number4.Name = "Number4"
        Me.Number4.Size = New System.Drawing.Size(86, 68)
        Me.Number4.TabIndex = 8
        Me.Number4.Text = "4"
        Me.Number4.UseVisualStyleBackColor = False
        '
        'Multiplication
        '
        Me.Multiplication.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Multiplication.Font = New System.Drawing.Font("Microsoft YaHei", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Multiplication.Location = New System.Drawing.Point(354, 297)
        Me.Multiplication.Name = "Multiplication"
        Me.Multiplication.Size = New System.Drawing.Size(86, 68)
        Me.Multiplication.TabIndex = 15
        Me.Multiplication.Text = "x"
        Me.Multiplication.UseVisualStyleBackColor = False
        '
        'Number9
        '
        Me.Number9.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Number9.Font = New System.Drawing.Font("Microsoft YaHei", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Number9.Location = New System.Drawing.Point(181, 151)
        Me.Number9.Name = "Number9"
        Me.Number9.Size = New System.Drawing.Size(86, 66)
        Me.Number9.TabIndex = 14
        Me.Number9.Text = "9"
        Me.Number9.UseVisualStyleBackColor = False
        '
        'Number8
        '
        Me.Number8.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Number8.Font = New System.Drawing.Font("Microsoft YaHei", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Number8.Location = New System.Drawing.Point(95, 151)
        Me.Number8.Name = "Number8"
        Me.Number8.Size = New System.Drawing.Size(86, 66)
        Me.Number8.TabIndex = 13
        Me.Number8.Text = "8"
        Me.Number8.UseVisualStyleBackColor = False
        '
        'Number7
        '
        Me.Number7.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Number7.Font = New System.Drawing.Font("Microsoft YaHei", 15.0!, System.Drawing.FontStyle.Bold)
        Me.Number7.Location = New System.Drawing.Point(9, 151)
        Me.Number7.Name = "Number7"
        Me.Number7.Size = New System.Drawing.Size(86, 66)
        Me.Number7.TabIndex = 12
        Me.Number7.Text = "7"
        Me.Number7.UseVisualStyleBackColor = False
        '
        'Division
        '
        Me.Division.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Division.Font = New System.Drawing.Font("Microsoft YaHei", 20.0!, System.Drawing.FontStyle.Bold)
        Me.Division.Location = New System.Drawing.Point(354, 223)
        Me.Division.Name = "Division"
        Me.Division.Size = New System.Drawing.Size(86, 68)
        Me.Division.TabIndex = 19
        Me.Division.Text = "÷"
        Me.Division.UseVisualStyleBackColor = False
        '
        'cancel1
        '
        Me.cancel1.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.cancel1.Font = New System.Drawing.Font("Microsoft YaHei", 15.0!, System.Drawing.FontStyle.Bold)
        Me.cancel1.Location = New System.Drawing.Point(181, 371)
        Me.cancel1.Name = "cancel1"
        Me.cancel1.Size = New System.Drawing.Size(86, 67)
        Me.cancel1.TabIndex = 18
        Me.cancel1.Text = "C"
        Me.cancel1.UseVisualStyleBackColor = False
        '
        'Erasebutton
        '
        Me.Erasebutton.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Erasebutton.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Erasebutton.Location = New System.Drawing.Point(267, 151)
        Me.Erasebutton.Name = "Erasebutton"
        Me.Erasebutton.Size = New System.Drawing.Size(173, 66)
        Me.Erasebutton.TabIndex = 20
        Me.Erasebutton.Text = "⌫"
        Me.Erasebutton.UseVisualStyleBackColor = False
        '
        'Label
        '
        Me.Label.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label.Font = New System.Drawing.Font("Microsoft YaHei", 30.0!, System.Drawing.FontStyle.Bold)
        Me.Label.Location = New System.Drawing.Point(12, 63)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(428, 79)
        Me.Label.TabIndex = 21
        Me.Label.Text = "0"
        Me.Label.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.ClientSize = New System.Drawing.Size(452, 443)
        Me.Controls.Add(Me.Label)
        Me.Controls.Add(Me.Erasebutton)
        Me.Controls.Add(Me.Division)
        Me.Controls.Add(Me.cancel1)
        Me.Controls.Add(Me.Multiplication)
        Me.Controls.Add(Me.Number9)
        Me.Controls.Add(Me.Number8)
        Me.Controls.Add(Me.Number7)
        Me.Controls.Add(Me.Subtraction)
        Me.Controls.Add(Me.Number6)
        Me.Controls.Add(Me.Number5)
        Me.Controls.Add(Me.Number4)
        Me.Controls.Add(Me.Addition)
        Me.Controls.Add(Me.Number3)
        Me.Controls.Add(Me.Number2)
        Me.Controls.Add(Me.Number1)
        Me.Controls.Add(Me.Equal)
        Me.Controls.Add(Me.Point)
        Me.Controls.Add(Me.Number0)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Calculator"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Number0 As Button
    Friend WithEvents Point As Button
    Friend WithEvents Equal As Button
    Friend WithEvents Addition As Button
    Friend WithEvents Number3 As Button
    Friend WithEvents Number2 As Button
    Friend WithEvents Number1 As Button
    Friend WithEvents Subtraction As Button
    Friend WithEvents Number6 As Button
    Friend WithEvents Number5 As Button
    Friend WithEvents Number4 As Button
    Friend WithEvents Multiplication As Button
    Friend WithEvents Number9 As Button
    Friend WithEvents Number8 As Button
    Friend WithEvents Number7 As Button
    Friend WithEvents Division As Button
    Friend WithEvents cancel1 As Button
    Friend WithEvents Erasebutton As Button
    Friend WithEvents Label As Label
End Class
